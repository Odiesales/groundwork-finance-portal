import sys
from pathlib import Path

import pandas as pd
import streamlit as st

APP_DIR = Path(__file__).resolve().parent
if str(APP_DIR) not in sys.path:
    sys.path.insert(0, str(APP_DIR))

from utils.paths import CURRENT_AR_PATH
from utils.data import ar_snapshot_files
from utils.ui import inject_global_css, sidebar_snapshot
from utils.google_drive import sync_from_drive

st.set_page_config(
    page_title="Groundwork AR & Deductions Portal",
    page_icon="☕",
    layout="wide",
    initial_sidebar_state="expanded",
)


def current_snapshot_date():
    snapshots = ar_snapshot_files()
    if snapshots:
        return snapshots[0][0]
    try:
        if CURRENT_AR_PATH.exists():
            df = pd.read_csv(CURRENT_AR_PATH, usecols=lambda c: c == "Snapshot Date")
            dates = pd.to_datetime(df.get("Snapshot Date"), errors="coerce").dropna()
            if not dates.empty:
                return dates.max()
    except Exception:
        pass
    return None


inject_global_css()

if "drive_initial_sync_complete" not in st.session_state:
    try:
        sync_from_drive()
        st.session_state["drive_initial_sync_complete"] = True
        st.session_state.pop("drive_initial_sync_error", None)
    except Exception as exc:
        st.session_state["drive_initial_sync_error"] = str(exc)

pages = [
    st.Page("pages/0_Executive_Scorecard.py", title="Executive Scorecard", icon="🏠", default=True),
    st.Page("pages/1_DSO.py", title="DSO", icon="⏱️"),
    st.Page("pages/1_Accounts_Receivable.py", title="Accounts Receivable", icon="💰"),
    st.Page("pages/2_Chargebacks.py", title="Chargebacks", icon="🏷️"),
    st.Page("pages/2_Chargeback_Analysis.py", title="CB Analysis", icon="🔎"),
    st.Page("pages/3_Trends.py", title="AR Trends", icon="📊"),
    st.Page("pages/99_Admin.py", title="Administration", icon="⚙️"),
]

nav = st.navigation(pages, position="sidebar")
sidebar_snapshot(current_snapshot_date())
nav.run()
