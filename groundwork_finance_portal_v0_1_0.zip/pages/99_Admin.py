import streamlit as st
from pathlib import Path
from datetime import date

st.set_page_config(page_title="Admin", page_icon="⚙️", layout="wide")

UPLOAD_DIR = Path("data/uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

st.title("⚙️ Admin")
st.caption("Version 0.1.0 — upload page")

st.subheader("Upload Weekly AR Aging")
snapshot_date = st.date_input("Snapshot date", value=date.today())
uploaded_file = st.file_uploader("Choose AR Aging Excel file", type=["xlsx", "xls", "csv"])

if uploaded_file is not None:
    target_path = UPLOAD_DIR / uploaded_file.name
    with open(target_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    st.success(f"Uploaded: {uploaded_file.name}")
    st.write(f"Snapshot date: {snapshot_date}")
    st.write(f"Saved to: {target_path}")

    st.warning("Processing is not connected yet. Version 0.2 will preview and clean this file.")
else:
    st.info("Upload your NetSuite AR Aging file here once the upload engine is ready.")
